import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import { Persona } from "../types";

// Note: In AI Studio, GEMINI_API_KEY is injected at runtime.
const apiKey = process.env.GEMINI_API_KEY;

if (!apiKey) {
  console.warn("GEMINI_API_KEY is missing. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || '' });

export async function getAnalogy(topic: string, persona: Persona) {
  if (!apiKey) {
    throw new Error("Gemini API Key is missing. Please configure it in the platform settings.");
  }

  const prompt = `You are a personalized AI tutor. 
Student persona: ${JSON.stringify(persona)}. 
Explain '${topic}' using a creative analogy from their world (their sport, hobby, or movie theme). 
Return ONLY JSON.`;

  const response = await ai.models.generateContent({
    model: "gemini-flash-latest",
    contents: prompt,
    config: {
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          analogy: { type: Type.STRING },
          explanation: { type: Type.STRING },
          example: { type: Type.STRING },
          fun_fact: { type: Type.STRING },
        },
        required: ["analogy", "explanation", "example", "fun_fact"],
      },
    },
  });

  return JSON.parse(response.text);
}

export async function getQuiz(topic: string, persona: Persona) {
  const prompt = `Generate 5 MCQ questions on '${topic}' for a student who loves ${persona.sport}. 
Make them scenario-based and fun. 
Return ONLY JSON.`;

  const response = await ai.models.generateContent({
    model: "gemini-flash-latest",
    contents: prompt,
    config: {
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                answer: { type: Type.STRING },
                explanation: { type: Type.STRING },
              },
              required: ["question", "options", "answer", "explanation"],
            },
          },
        },
        required: ["questions"],
      },
    },
  });

  return JSON.parse(response.text);
}

export async function evaluateExplanation(topic: string, explanation: string) {
  const prompt = `Student explained '${topic}' as: '${explanation}'. Is this correct and complete? Return ONLY JSON.`;

  const response = await ai.models.generateContent({
    model: "gemini-flash-latest",
    contents: prompt,
    config: {
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          correct: { type: Type.BOOLEAN },
          score: { type: Type.NUMBER },
          feedback: { type: Type.STRING },
          missing_points: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: ["correct", "score", "feedback", "missing_points"],
      },
    },
  });

  return JSON.parse(response.text);
}

export async function getRerouteSuggestions(weakTopics: string[], persona: Persona) {
  const prompt = `Student is weak at ${weakTopics.join(", ")}. Their persona: ${JSON.stringify(persona)}. 
Suggest a fun re-learning path using their interests. Return ONLY JSON.`;

  const response = await ai.models.generateContent({
    model: "gemini-flash-latest",
    contents: prompt,
    config: {
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          path: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                topic: { type: Type.STRING },
                analogy_hint: { type: Type.STRING },
                priority: {
                  type: Type.STRING,
                  enum: ["high", "medium", "low"],
                },
              },
              required: ["topic", "analogy_hint", "priority"],
            },
          },
        },
        required: ["path"],
      },
    },
  });

  return JSON.parse(response.text);
}
